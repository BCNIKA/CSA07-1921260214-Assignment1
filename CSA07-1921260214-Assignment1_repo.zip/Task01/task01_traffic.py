"""Task 1 - Size the traffic of the smart plant (CSA07 Computer Networks, Assignment 1).

All rates are in Mbps (1 Mbps = 1,000,000 bit/s, 1 Gbps = 1,000 Mbps).
Assumption: every source's traffic crosses the shop-floor uplink (worst case).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

UPLINK_MBPS = 1000.0
LINES = 8
ETH_OVERHEAD = 38          # preamble 8 + header 14 + FCS 4 + inter-frame gap 12 bytes
PKT_BYTES = 1500           # full-size packet used for queue calculations
TARGET_UTIL = 0.70         # planning limit for a link carrying delay-sensitive traffic

# ---------- 1. traffic of one line ----------
robot_n, robot_bytes, robot_interval = 40, 200, 0.002
sens_n, sens_bytes = 600, 50
cctv_n, cctv_mbps = 24, 4.0
office_n, office_mbps, office_active = 150, 2.0, 0.10

robot_rate_each = robot_bytes * 8 / robot_interval / 1e6
robot_total = robot_n * robot_rate_each
sens_total = sens_n * sens_bytes * 8 / 1e6
cctv_total = cctv_n * cctv_mbps
office_total = office_n * office_active * office_mbps
line = robot_total + sens_total + cctv_total + office_total

print("=== 1. Traffic of ONE production line ===")
print(f"Robot commands : {1/robot_interval:.0f} cmd/s x {robot_bytes} B x 8 = {robot_rate_each:.3f} Mbps each; x {robot_n} = {robot_total:.3f} Mbps")
print(f"Vibration      : {sens_n} x {sens_bytes} B/s x 8 = {sens_total*1000:.0f} kbps = {sens_total:.3f} Mbps")
print(f"CCTV           : {cctv_n} x {cctv_mbps} Mbps = {cctv_total:.3f} Mbps")
print(f"Office (peak)  : {office_n} x {office_active:.0%} = {office_n*office_active:.0f} active users x {office_mbps} Mbps = {office_total:.3f} Mbps")
print(f"TOTAL one line : {line:.3f} Mbps")
for name, v in [("Robot", robot_total), ("Vibration", sens_total), ("CCTV", cctv_total), ("Office", office_total)]:
    print(f"   share {name:<10}: {v/line:6.1%}")
plant = line * LINES
print(f"TOTAL plant ({LINES} lines): {plant:.3f} Mbps = {plant/1000:.4f} Gbps")

robot_wire_each = (robot_bytes + ETH_OVERHEAD) * 8 / robot_interval / 1e6
print(f"\nSensitivity: robot frame on the wire = {robot_bytes}+{ETH_OVERHEAD} = {robot_bytes+ETH_OVERHEAD} B -> {robot_wire_each:.3f} Mbps each, "
      f"{robot_wire_each*robot_n:.3f} Mbps for 40; line total {line - robot_total + robot_wire_each*robot_n:.3f} Mbps")

# ---------- 2. biggest source and strictest delay ----------
print("\n=== 2. Biggest source vs strictest delay ===")
print(f"Largest volume : CCTV, {cctv_total:.0f} Mbps = {cctv_total/line:.1%} of the line")
print(f"Strictest delay: robot controllers, 10 ms deadline (only {robot_total/line:.1%} of the volume)")
print("Same source?   : NO")

# ---------- 3. 1 Gbps uplink ----------
print("\n=== 3. Is one 1 Gbps uplink enough? ===")
print(f"One line  : {line:.2f} Mbps = {line/UPLINK_MBPS:.1%} of 1 Gbps  -> enough")
print(f"Plant (8) : {plant:.2f} Mbps = {plant/UPLINK_MBPS:.1%} of 1 Gbps  -> NOT enough (over-subscribed by {plant-UPLINK_MBPS:.2f} Mbps)")
print(f"Lines that fit at 100% = {UPLINK_MBPS/line:.2f} -> {int(UPLINK_MBPS//line)}; at {TARGET_UTIL:.0%} planning limit = {TARGET_UTIL*UPLINK_MBPS/line:.2f} -> {int(TARGET_UTIL*UPLINK_MBPS//line)}")

print("\nQueue delay on a shared FIFO queue (M/M/1 approximation, 1500-byte packets):")
mu = UPLINK_MBPS * 1e6 / (PKT_BYTES * 8)
service_us = 1e6 / mu
print(f"  service rate mu = {mu:,.0f} packets/s; one packet takes {service_us:.1f} microseconds to send")
print(f"  {'case':<26}{'load Mbps':>10}{'utilisation':>13}{'mean delay':>16}")
cases = [("1 line", line), ("4 lines", 4 * line), ("6 lines", 6 * line), ("6.3 lines (99%)", 0.99 * UPLINK_MBPS)]
for name, load in cases:
    rho = load / UPLINK_MBPS
    w = 1e6 / (mu * (1 - rho))
    print(f"  {name:<26}{load:>10.1f}{rho:>13.1%}{w:>13.1f} us")
print(f"  {'8 lines':<26}{plant:>10.1f}{plant/UPLINK_MBPS:>13.1%}   queue grows without limit -> buffer fills, packets dropped")
excess = plant - UPLINK_MBPS
print(f"  Excess arrival = {excess:.2f} Mbps")
for buf_kb in (512, 1024, 2048):
    drain_ms = buf_kb * 1024 * 8 / (UPLINK_MBPS * 1e6) * 1000
    fill_ms = buf_kb * 1024 * 8 / (excess * 1e6) * 1000
    print(f"    buffer {buf_kb:>4} KB: a robot frame waits up to {drain_ms:5.2f} ms when full; buffer fills in {fill_ms:6.1f} ms")

burst_bytes = 64 * 1024
burst_total = cctv_n * burst_bytes
burst_delay = burst_total * 8 / (UPLINK_MBPS * 1e6) * 1000
print(f"\nMicroburst: {cctv_n} cameras each send one {burst_bytes//1024} KB video I-frame at the same instant (assumption)")
print(f"  queue = {burst_total:,} bytes -> a robot command behind it waits {burst_delay:.2f} ms  (deadline 10 ms -> MISSED by {burst_delay-10:.2f} ms)")
print(f"  with strict priority for robot traffic: wait <= one frame in service = {PKT_BYTES*8/1e9*1e6:.0f} us at 1 Gbps "
      f"({PKT_BYTES*8/100e6*1e6:.0f} us on a 100 Mbps port)")

# ---------- 4. ranking ----------
print("\n=== 4. Ranking by harm of a 100 ms delay ===")
print(f"  Robot: 100 ms / 2 ms interval = {100/2:.0f} consecutive commands late (deadline is 10 ms -> {100/10:.0f}x too late)")
print(f"  Vibration: 100 ms is {0.1/1:.0%} of the 1 s reporting interval")
ranking = ["1 Robot control (safety, 10 ms deadline)", "2 Office ERP/e-mail (interactive)", "3 CCTV live view (buffered)", "4 Vibration sensors (monitoring)"]
for r in ranking: print("  ", r)

# ---------- 5. alternative: motion-triggered CCTV ----------
print("\n=== 5. Alternative: motion-triggered CCTV (5% of time) ===")
cctv_alt = cctv_total * 0.05
line_alt = robot_total + sens_total + cctv_alt + office_total
plant_alt = line_alt * LINES
print(f"CCTV           : {cctv_total:.0f} x 5% = {cctv_alt:.2f} Mbps")
print(f"One line       : {line_alt:.3f} Mbps (was {line:.3f}; saving {1-line_alt/line:.1%})")
print(f"Plant (8 lines): {plant_alt:.3f} Mbps = {plant_alt/UPLINK_MBPS:.1%} of 1 Gbps (was {plant/UPLINK_MBPS:.1%})")
print(f"Lines at {TARGET_UTIL:.0%} limit: {TARGET_UTIL*UPLINK_MBPS/line_alt:.2f} -> {int(TARGET_UTIL*UPLINK_MBPS//line_alt)} lines (was {int(TARGET_UTIL*UPLINK_MBPS//line)})")
rho_alt = plant_alt / UPLINK_MBPS
print(f"Mean queue delay at {rho_alt:.1%}: {1e6/(mu*(1-rho_alt)):.1f} us")
print(f"Worst case, all 24 cameras trigger together: line = {robot_total+sens_total+cctv_total+office_total:.1f} Mbps for the clip duration -> burst risk remains")
store_gb_day = cctv_mbps * 1e6 / 8 * 86400 / 1e9
print(f"Local recording: {cctv_mbps} Mbps = {cctv_mbps/8:.1f} MB/s = {store_gb_day:.1f} GB per camera per day; {store_gb_day*cctv_n/1000:.2f} TB/day for {cctv_n} cameras")
print("Is 1 Gbps still the bottleneck? NO for 8 lines; the largest remaining flows are robot (32) and office (30) traffic.")

# ---------- figures ----------
labels = ["Robot\ncontrollers", "Vibration\nsensors", "CCTV\n(continuous)", "Office\nusers"]
vol = [robot_total, sens_total, cctv_total, office_total]
delay_ms = [10, 1000, 300, 150]   # assumed tolerable delay per traffic type (ms)
fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
b = ax[0].bar(labels, vol, color=["#c0392b", "#2980b9", "#7f8c8d", "#27ae60"])
ax[0].set_ylabel("Mbps per line"); ax[0].set_title("Volume per production line")
for r, v in zip(b, vol): ax[0].text(r.get_x() + r.get_width()/2, v + 1.5, f"{v:.2f}", ha="center", fontsize=9)
b2 = ax[1].bar(labels, delay_ms, color=["#c0392b", "#2980b9", "#7f8c8d", "#27ae60"])
ax[1].set_yscale("log"); ax[1].set_ylim(5, 3000); ax[1].set_ylabel("tolerable delay (ms, log scale)"); ax[1].set_title("Delay requirement")
ax[1].axhline(100, color="k", ls="--", lw=1); ax[1].text(3.45, 112, "100 ms", ha="right", fontsize=8)
for r, v in zip(b2, delay_ms): ax[1].text(r.get_x() + r.get_width()/2, v * 1.12, f"{v}", ha="center", fontsize=9)
plt.tight_layout(); plt.savefig("fig_volume_vs_delay.png", dpi=150); plt.close()

scen = ["Mean delay,\n1 line (M/M/1)", "FIFO, 512 KB\nbuffer full", "FIFO, 1 MB\nbuffer full", "FIFO, 24-camera\nburst", "FIFO, 2 MB\nbuffer full", "Strict priority\nfor robots"]
vals = [1e6/(mu*(1-line/UPLINK_MBPS))/1000, 512*1024*8/1e9*1000, 1024*1024*8/1e9*1000, burst_delay, 2048*1024*8/1e9*1000, PKT_BYTES*8/1e9*1000]
cols = ["#27ae60" if v < 10 else "#c0392b" for v in vals]
fig, ax = plt.subplots(figsize=(9, 3.9))
bars = ax.bar(scen, vals, color=cols)
ax.axhline(10, color="k", ls="--", lw=1); ax.text(5.45, 10.4, "robot deadline 10 ms", ha="right", fontsize=8)
for r, v in zip(bars, vals): ax.text(r.get_x() + r.get_width()/2, v + 0.3, f"{v:.3f}" if v < 1 else f"{v:.2f}", ha="center", fontsize=9)
ax.set_ylabel("wait of one robot command (ms)"); ax.set_ylim(0, 19)
ax.set_title("How long a robot command waits at the 1 Gbps uplink"); plt.tight_layout(); plt.savefig("fig_queue_delay.png", dpi=150)
print("\nfigures saved: fig_volume_vs_delay.png, fig_queue_delay.png")
