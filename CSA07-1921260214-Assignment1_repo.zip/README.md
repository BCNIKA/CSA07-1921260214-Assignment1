# CSA07 – Computer Networks – Assignment 1

| | |
|---|---|
| Name | Yashwanth Bewan A |
| Register number | 1921260214 |
| Department | IT |
| Repository | https://github.com/BCNIKA/CSA07-1921260214-Assignment1 |

## Environment (update to match your machine)
- Operating system: Ubuntu 24.04 (Linux)
- Python: 3.12.3
- Libraries: see `requirements.txt` (matplotlib)
- Cisco Packet Tracer / NS-3: not needed for Task 1 (will be listed when a later task uses it)

## How to run
```
pip install -r requirements.txt
cd Task01
python3 task01_traffic.py        # prints all calculations, saves fig_volume_vs_delay.png and fig_queue_delay.png
```

## Progress
| Task | Folder | Status | Result in one line |
|---|---|---|---|
| 1 | `Task01/` | Done | One line = 158.24 Mbps (CCTV 96, robots 32, office 30, sensors 0.24); 8 lines = 1,265.92 Mbps, so one 1 Gbps uplink is enough for a line but not for the plant; CCTV is the largest flow, robots have the strictest delay (10 ms); motion-triggered CCTV cuts the plant to 536.32 Mbps (53.6 %). |
| 2–12 | | Pending | |
